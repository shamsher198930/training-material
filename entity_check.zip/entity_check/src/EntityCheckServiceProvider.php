<?php
namespace Drupal\entity_check;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;
use Symfony\Component\DependencyInjection\Reference;


/**
 * Modifies the language manager service.
 */
class EntityCheckServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container) {
    $definition = $container->getDefinition('user.auth');
    $definition->setClass('Drupal\entity_check\UserAuth');
    $definition->setArguments(
      [
        new Reference('entity.manager'),
        new Reference('password'),
      ]
    );
  }
}
