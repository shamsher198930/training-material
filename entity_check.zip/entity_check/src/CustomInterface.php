<?php

namespace Drupal\entity_check;

/**
 * Interface CustomInterface.
 */
interface CustomInterface {

//public function collectorCheck($data);
}
