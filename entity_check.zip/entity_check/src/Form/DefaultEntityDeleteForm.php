<?php

namespace Drupal\entity_check\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Default entity entities.
 *
 * @ingroup entity_check
 */
class DefaultEntityDeleteForm extends ContentEntityDeleteForm {


}
