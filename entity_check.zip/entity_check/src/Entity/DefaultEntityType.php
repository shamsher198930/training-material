<?php

namespace Drupal\entity_check\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the Default entity type entity.
 *
 * @ConfigEntityType(
 *   id = "default_entity_type",
 *   label = @Translation("Default entity type"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\entity_check\DefaultEntityTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\entity_check\Form\DefaultEntityTypeForm",
 *       "edit" = "Drupal\entity_check\Form\DefaultEntityTypeForm",
 *       "delete" = "Drupal\entity_check\Form\DefaultEntityTypeDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\entity_check\DefaultEntityTypeHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "default_entity_type",
 *   admin_permission = "administer site configuration",
 *   bundle_of = "default_entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/default_entity_type/{default_entity_type}",
 *     "add-form" = "/admin/structure/default_entity_type/add",
 *     "edit-form" = "/admin/structure/default_entity_type/{default_entity_type}/edit",
 *     "delete-form" = "/admin/structure/default_entity_type/{default_entity_type}/delete",
 *     "collection" = "/admin/structure/default_entity_type"
 *   }
 * )
 */
class DefaultEntityType extends ConfigEntityBundleBase implements DefaultEntityTypeInterface {

  /**
   * The Default entity type ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Default entity type label.
   *
   * @var string
   */
  protected $label;

}
