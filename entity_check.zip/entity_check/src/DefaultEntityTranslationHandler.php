<?php

namespace Drupal\entity_check;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for default_entity.
 */
class DefaultEntityTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
