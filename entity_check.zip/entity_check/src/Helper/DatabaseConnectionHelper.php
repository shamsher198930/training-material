<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Drupal\entity_check\Helper;

/**
 * Description of DatabaseConnectionHelper
 *
 * @author harbehl
 */
class DatabaseConnectionHelper {
  //put your code here
  
  public static function getProceduralDbConnection() {
    $database = \Drupal::database();
    return $database;
  }
  public static function getProceduralDbServiceConnection() {
    $database = \Drupal::service('database');
    return $database;
  }
  
  public static function getConnectionUsingService() {
    $service = \Drupal::service('entity_check.default');
    return $service->getConnectionFromCustomService();
  }
  
  public static function getConnectionWhenServiceNotAvailable() {
    return \Drupal\Core\Database\Database::getConnection();
  }
    
  public static function switchDatabases() {
    $connections = [];
     $db = \Drupal\Core\Database\Database::setActiveConnection('external');
     $connection['external'] = $db;
//     kint(self::getProceduralDbServiceConnection());
     $dbOriginal = \Drupal\Core\Database\Database::setActiveConnection('default');
     $connection['default'] = $dbOriginal;
//     kint(self::getProceduralDbServiceConnection());
     return $connection;
  }
  
  public static function staticQuery() {
    $connection = self::getProceduralDbServiceConnection();
    $result = $connection->query("SELECT * FROM node");
    
    foreach ($result as $record) {
//      kint($record);
      // Do something with each $record
    }
    return $result;
  }
  
  public static function dynamicQuery() {
    $connection = self::getProceduralDbServiceConnection();
    $result = $connection->select('node', 'n')->fields('n', [])->execute();
    
    foreach ($result as $record) {
//      kint($record);
      // Do something with each $record
    }
    return $result;
  }
  
  public static function startTransaction() {
    $connection = self::getProceduralDbConnection();
    $transction = $connection->startTransaction();
    try{
      self::dynamicQuery();
    }
    catch (Exception $e) {
      $transaction->rollBack();
      watchdog_exception('my_type', $e);
    }
  }
}
