<?php
namespace Drupal\entity_check\Helper;

class UtilityHelper {
  
  public static function myHelperFunction() {
    return ['Some Values'];
  }
  
}