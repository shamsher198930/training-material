<?php

namespace Drupal\entity_check;

/**
 * Interface TrainingServiceInterface.
 */
interface TrainingServiceInterface {


}
