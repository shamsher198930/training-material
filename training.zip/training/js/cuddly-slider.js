jQuery(document).ready(
    function () {
        // alert('test123');
        // Do some fancy stuff.
    }
);
