/**
 * @file
 */

var Drupal = Drupal || {};

(function ($, Drupal, drupalSettings) {
  "use strict";
  Drupal.behaviors.cp_form = {
    attach: function (context, settings) {

//      alert('test');
    }
  };

})(jQuery, Drupal, drupalSettings);
