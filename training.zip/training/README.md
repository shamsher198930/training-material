Lorem ipsum
===========

Lorem ipsum generator for Drupal.

Instructions
------------

Lorem ipsum dolor sit amet... **Just kidding!**

Unpack in the *modules* folder (currently in the root of your Drupal 8
installation) and enable in `/admin/modules`.

Then, visit `/admin/config/development/loremipsum` and enter your own set of
phrases to build random-generated text (or go with the default Lorem ipsum).

Last, visit `www.example.com/loremipsum/generate/P/S` where:
- *P* is the number of *paragraphs*
- *S* is the maximum number of *sentences*

There is also a generator block in which you can choose how many paragraphs and
phrases and it'll do the rest.

If you need, there's also a specific *generate lorem ipsum* permission.

Attention
---------

Most bugs have been ironed out, holes covered, features added. But this module
is a work in progress. Please report bugs and suggestions, ok?