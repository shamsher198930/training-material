<?php

namespace Drupal\Tests\training\Kernel;

use Drupal\KernelTests\KernelTestBase;

/**
 * Tests the TrainingService
 *
 * @group training
 */
class TrainingServiceTest extends KernelTestBase {

  /**
   * The service under test.
   *
   * @var \Drupal\training\TrainingServiceInterface
   */
  protected $trainingService;

  /**
   * The modules to load to run the test.
   *
   * @var array
   */
  public static $modules = [
    'training',
  ];

  /**
   * {@inheritdoc}
   */
  protected function setUp() {
    parent::setUp();

    $this->installConfig(['training']);

    $this->trainingService = \Drupal::service('training.training');
  }

  public function testName() {
    $label = $this->trainingService->getName();
    $this->assertTrue($label == 'Shamsher', $label);
  }

  public function testlast() {
    $message = $this->trainingService->getlast();
    $this->assertTrue($message == 'Alam', $message);
  }
}
