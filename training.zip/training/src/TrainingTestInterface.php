<?php

namespace Drupal\training;

/**
 * Interface TrainingTestInterface.
 */
interface TrainingTestInterface {


}
