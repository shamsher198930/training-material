<?php

namespace Drupal\training\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'CustomBlock2' block.
 *
 * @Block(
 *  id = "custom_block2",
 *  admin_label = @Translation("Custom block2"),
 * )
 */
class CustomBlock2 extends BlockBase
{

    /**
     * {@inheritdoc}
     */
    public function build()
    {
        $build = [];
        $build['#theme'] = 'custom_block2';
        $build['custom_block2']['#markup'] = 'Implement CustomBlock2.';

        return $build;
    }

}
