<?php

namespace Drupal\training\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'DefaultBlock' block.
 *
 * @Block(
 *  id = "default_block",
 *  admin_label = @Translation("Default block"),
 * )
 */
class DefaultBlock extends BlockBase implements BlockPluginInterface {

  /**
   * {@inheritdoc}
   */
  public function build() {
    
//    $config = $this->getConfiguration();
//
//    if (!empty($config['hello_block_name'])) {
//      $name = $config['hello_block_name'];
//    }
//    else {
//      $name = $this->t('to no one');
//    }
    
    $test = $this->xyz();
    $build = [];
    return [
      '#type' => 'markup',
      '#markup' => $test,
    ];
    $build['#theme'] = 'default_block';
     $build['#content'] = $test;
     $build['#content2'] = $test;

    return $build;
  }

  public function xyz() {
    return "Hello World!!!";
  }
  
  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form = parent::blockForm($form, $form_state);

    $config = $this->getConfiguration();

    $form['hello_block_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Who'),
      '#description' => $this->t('Who do you want to say hello to?'),
      '#default_value' => isset($config['hello_block_name']) ? $config['hello_block_name'] : '',
    ];

    return $form;
  }
  
  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    parent::blockSubmit($form, $form_state);
    $values = $form_state->getValues();
    $this->configuration['hello_block_name'] = $values['hello_block_name'];
  }
}
