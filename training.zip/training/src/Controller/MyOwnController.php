<?php

namespace Drupal\training\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class DefaultController.
 */
class MyOwnController extends ControllerBase
{

    /**
     * Drupal\Core\Logger\LoggerChannelFactoryInterface definition.
     *
     * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
     */
    protected $loggerFactory;

    /**
     * Drupal\Core\Database\Driver\mysql\Connection definition.
     *
     * @var \Drupal\Core\Database\Driver\mysql\Connection
     */
    protected $database;

    /**
     * {@inheritdoc}
     */
    public static function create(ContainerInterface $container)
    {
        $instance = parent::create($container);
        $instance->loggerFactory = $container->get('logger.factory');
        $instance->database = $container->get('database');
        return $instance;
    }

    /**
     * Abc.
     *
     * @return string
     *   Return Hello string.
     */
    public function pqr()
    {
      
      $client = \GuzzleHttp\Client();
      $request = $client->get('http://training.local/node/25',['auth' => ['uname', 'pass']]);
      $response = $request->makecall();
      uname & pass
      
      
      $response->getBody();
      $response->getHeaders();
      
        $default_config = \Drupal::config('training.settings');
        $editableConfig = \Drupal::configFactory()->getEditable('training.settings');
        $editableConfig->set('hello.name', 'Drupal Training');
        $editableConfig->save();
        $xyz = $this->xyz();
        //    return [
        //      '#type' => 'markup',
        //      '#markup' => $editableConfig->get('hello.name')
        //    ];
        return [
        '#theme' => 'default_block',
        '#content' => $editableConfig->get('hello.name'),
        '#content2' => 'Training Test values goes here.'
        ];
    }

    public function xyz()
    {
        return 'Hello !!';
    }
}
