<?php

namespace Drupal\training\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use GuzzleHttp\Client;
use Drupal\Component\Utility\Xss;
use Drupal\node\NodeInterface;

/**
 * Class DefaultController.
 */
class DefaultController extends ControllerBase {

  /**
   * Drupal\Core\Logger\LoggerChannelFactoryInterface definition.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Drupal\Core\Database\Driver\mysql\Connection definition.
   *
   * @var \Drupal\Core\Database\Driver\mysql\Connection
   */
  protected $database;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->loggerFactory = $container->get('logger.factory');
    $instance->database = $container->get('database');
    return $instance;
  }

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function build(NodeInterface $node) {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }

  public function custom($custom) {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }
  
  /**
   * Abc.
   *
   * @return string
   *   Return Hello string.
   */
  public function abc() {
    $xyz = $this->xyz();
    new Client();
    return [
      '#theme' => 'mymodule_template',
      '#test_var' => [$xyz, 'test3 double'],
    ];
  }

  public function xyz() {
    return $this->t(Xss::filter('<h1>Hello !!</h1> <h1>Hello !!</h1> <h1>Hello !!</h1> '));
  }

}
