<?php

namespace Drupal\training;

/**
 * Interface DefaultServiceInterface.
 */
interface DefaultServiceInterface {


}
