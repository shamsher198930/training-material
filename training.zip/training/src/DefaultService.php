<?php

namespace Drupal\training;

/**
 * Class DefaultService.
 */
class DefaultService implements DefaultServiceInterface {

  /**
   * Constructs a new DefaultService object.
   */
  public function __construct() {

  }

}
